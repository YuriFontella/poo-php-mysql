<?php require_once('./lib/db.php'); ?>
<?php require_once('./lib/query.php'); ?>

<?php require_once('./layout/template.php'); ?>